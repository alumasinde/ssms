package repositories

import (
	models "school-ms/internal/Modules/Classes/Models"

	"github.com/jmoiron/sqlx"
)

type ClassSubjectRepository struct {
	db *sqlx.DB
}

func NewClassSubjectRepository(db *sqlx.DB) *ClassSubjectRepository {
	return &ClassSubjectRepository{
		db: db,
	}
}

func (r *ClassSubjectRepository) AssignSubject(
	classID,
	subjectID int64,
	compulsory bool,
) error {

	_, err := r.db.Exec(`
		INSERT INTO class_subjects
			(class_id, subject_id, is_compulsory)
		VALUES (?, ?, ?)
		ON DUPLICATE KEY UPDATE
			is_compulsory = VALUES(is_compulsory)
	`, classID, subjectID, compulsory)

	return err
}

func (r *ClassSubjectRepository) RemoveSubject(
	classID,
	subjectID int64,
) error {

	_, err := r.db.Exec(`
		DELETE FROM class_subjects
		WHERE class_id=? AND subject_id=?
	`, classID, subjectID)

	return err
}

func (r *ClassSubjectRepository) ListSubjects(
	classID int64,
) ([]models.ClassSubject, error) {

	var list []models.ClassSubject

	err := r.db.Select(
		&list,
		`
		SELECT
			cs.id,
			cs.class_id,
			cs.subject_id,
			cs.is_compulsory,
			s.name AS subject_name,
			s.code AS subject_code
		FROM class_subjects cs
		JOIN subjects s
			ON s.id = cs.subject_id
		WHERE cs.class_id=?
		ORDER BY s.name
		`,
		classID,
	)

	return list, err
}

func (r *ClassSubjectRepository) ListUnassignedSubjects(
	classID,
	schoolID int64,
) ([]models.ClassSubject, error) {

	var list []models.ClassSubject

	err := r.db.Select(
		&list,
		`
		SELECT
			0 AS id,
			? AS class_id,
			s.id AS subject_id,
			1 AS is_compulsory,
			s.name AS subject_name,
			s.code AS subject_code
		FROM subjects s
		WHERE s.school_id=?
		AND s.is_active=1
		AND s.id NOT IN (
			SELECT subject_id
			FROM class_subjects
			WHERE class_id=?
		)
		ORDER BY s.name
		`,
		classID,
		schoolID,
		classID,
	)

	return list, err
}