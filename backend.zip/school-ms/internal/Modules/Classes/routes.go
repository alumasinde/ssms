package classes

import (
	handlers "school-ms/internal/Modules/Classes/Handlers"
	repos "school-ms/internal/Modules/Classes/Repositories"
	services "school-ms/internal/Modules/Classes/Services"
	"school-ms/internal/middleware"

	"github.com/go-chi/chi/v5"
	"github.com/jmoiron/sqlx"
)

func RegisterRoutes(r chi.Router, db *sqlx.DB) {
	// Classes
	repo := repos.NewClassRepository(db)
	svc := services.NewClassService(repo)
	h := handlers.NewClassHandler(svc)

	// Class Subjects
	classSubjectRepo := repos.NewClassSubjectRepository(db)
	classSubjectSvc := services.NewClassSubjectService(classSubjectRepo)
	classSubjectHandler := handlers.NewClassSubjectHandler(classSubjectSvc)

	r.Route("/classes", func(r chi.Router) {
		r.Use(middleware.Authenticate)

		// Class routes
		r.With(middleware.RequirePermission(db, "classes.view")).Get("/", h.List)
		r.With(middleware.RequirePermission(db, "classes.create")).Post("/", h.Create)
		r.With(middleware.RequirePermission(db, "classes.view")).Get("/{id}", h.Get)
		r.With(middleware.RequirePermission(db, "classes.edit")).Put("/{id}", h.Update)
		r.With(middleware.RequirePermission(db, "classes.delete")).Delete("/{id}", h.Delete)

		// Class subject routes
		r.With(middleware.RequirePermission(db, "classes.view")).
			Get("/{id}/subjects", classSubjectHandler.List)

		r.With(middleware.RequirePermission(db, "classes.edit")).
			Post("/{id}/subjects", classSubjectHandler.Assign)

		r.With(middleware.RequirePermission(db, "classes.edit")).
			Delete("/{id}/subjects/{subjectId}", classSubjectHandler.Remove)
	})
}