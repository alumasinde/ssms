package handlers

import (
	"encoding/json"
	"net/http"
	"strconv"

	services "school-ms/internal/Modules/Classes/Services"
	"school-ms/internal/pkg/response"

	"github.com/go-chi/chi/v5"
)

type AssignSubjectDTO struct {
	SubjectID    int64 `json:"subject_id"`
	IsCompulsory bool  `json:"is_compulsory"`
}

type ClassSubjectHandler struct {
	svc *services.ClassSubjectService
}



func NewClassSubjectHandler(
	svc *services.ClassSubjectService,
) *ClassSubjectHandler {

	return &ClassSubjectHandler{
		svc: svc,
	}
}

func (h *ClassSubjectHandler) List(
	w http.ResponseWriter,
	r *http.Request,
) {

	classID, err := strconv.ParseInt(
		chi.URLParam(r, "id"),
		10,
		64,
	)

	if err != nil {
		response.BadRequest(w, "invalid class id")
		return
	}

	list, err := h.svc.List(classID)
	if err != nil {
		response.InternalError(w, err.Error())
		return
	}

	response.Success(w, list, "")
}

func (h *ClassSubjectHandler) Assign(
	w http.ResponseWriter,
	r *http.Request,
) {

	classID, err := strconv.ParseInt(
		chi.URLParam(r, "id"),
		10,
		64,
	)

	if err != nil {
		response.BadRequest(w, "invalid class id")
		return
	}

	var dto AssignSubjectDTO

	if err := json.NewDecoder(r.Body).Decode(&dto); err != nil {
		response.BadRequest(w, "invalid payload")
		return
	}

	err = h.svc.Assign(
		classID,
		dto.SubjectID,
		dto.IsCompulsory,
	)

	if err != nil {
		response.InternalError(w, err.Error())
		return
	}

	response.Success(w, nil, "subject assigned")
}

func (h *ClassSubjectHandler) Remove(
	w http.ResponseWriter,
	r *http.Request,
) {

	classID, err := strconv.ParseInt(
		chi.URLParam(r, "id"),
		10,
		64,
	)

	if err != nil {
		response.BadRequest(w, "invalid class id")
		return
	}

	subjectID, err := strconv.ParseInt(
		chi.URLParam(r, "subjectId"),
		10,
		64,
	)

	if err != nil {
		response.BadRequest(w, "invalid subject id")
		return
	}

	err = h.svc.Remove(
		classID,
		subjectID,
	)

	if err != nil {
		response.InternalError(w, err.Error())
		return
	}

	response.Success(w, nil, "subject removed")
}