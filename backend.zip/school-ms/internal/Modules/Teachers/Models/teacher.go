package models

type Teacher struct {
	ID            int64   `db:"id"            json:"id"`
	UserID        int64   `db:"user_id"       json:"user_id"`
	SchoolID      int64   `db:"school_id"     json:"school_id"`
	EmployeeNo    string  `db:"employee_no"   json:"employee_no"`
	Phone         *string `db:"phone"         json:"phone"`
	Gender        *string `db:"gender"        json:"gender"`
	DOB           *string `db:"dob"           json:"dob"`
	TSCNo         *string `db:"tsc_no"        json:"tsc_no"`
	HireDate      *string `db:"hire_date"     json:"hire_date"`
	Qualification *string `db:"qualification" json:"qualification"`
	PhotoURL      *string `db:"photo_url"     json:"photo_url"`
	IsActive      bool    `db:"is_active"     json:"is_active"`
}

type TeacherDetail struct {
	Teacher
	Name  string `db:"name"  json:"name"`
	Email string `db:"email" json:"email"`
}

type TeacherSubject struct {
	ID        int64 `db:"id"         json:"id"`
	TeacherID int64 `db:"teacher_id" json:"teacher_id"`
	SubjectID int64 `db:"subject_id" json:"subject_id"`
	ClassID   int64 `db:"class_id"   json:"class_id"`
}

type TeacherSubjectDetail struct {
	TeacherSubject
	SubjectName string `db:"subject_name" json:"subject_name"`
	SubjectCode string `db:"subject_code" json:"subject_code"`
	ClassName   string `db:"class_name"   json:"class_name"`
}
