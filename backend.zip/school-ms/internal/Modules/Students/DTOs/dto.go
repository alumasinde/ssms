package dtos

import "time"

type CreateStudentDTO struct {
	SchoolID    int64      `json:"school_id"`
	ClassID     int64      `json:"class_id"`
	AdmissionNo string     `json:"admission_no"`
	FirstName   string     `json:"first_name"`
	MiddleName  *string    `json:"middle_name"`
	LastName    string     `json:"last_name"`
	Gender      *string    `json:"gender"`
	DOB         *time.Time `json:"dob"`
	Nationality *string    `json:"nationality"`
	NationalID  *string    `json:"national_id"`
	Religion    *string    `json:"religion"`
	BloodGroup  *string    `json:"blood_group"`
	Address     *string    `json:"address"`
	PhotoURL    string     `json:"photo_url"`
}

type PromoteStudentsDTO struct {
	FromClassID int64   `json:"from_class_id"`
	ToClassID   int64   `json:"to_class_id"`
	StudentIDs  []int64 `json:"student_ids"` // empty = promote whole class
}
