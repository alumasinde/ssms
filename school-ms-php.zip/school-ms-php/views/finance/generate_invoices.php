<div class="row justify-content-center"><div class="col-lg-6">
<div class="card">
  <div class="card-header py-3"><i class="bi bi-file-earmark-plus me-2 text-primary"></i>Generate Invoices</div>
  <div class="card-body">
    <p class="text-muted small mb-3">Generate fee invoices for all students (or a specific class) for a given term and fee type.</p>
    <form method="POST" action="/finance/invoices/generate">
      <div class="mb-3"><label class="form-label small fw-semibold">Term ID *</label>
        <input type="number" name="term_id" class="form-control" required placeholder="Current term ID"></div>
      <div class="mb-3"><label class="form-label small fw-semibold">Fee Type ID *</label>
        <input type="number" name="fee_type_id" class="form-control" required></div>
      <div class="mb-3"><label class="form-label small fw-semibold">Class (leave blank = all classes)</label>
        <input type="number" name="class_id" class="form-control" placeholder="Optional"></div>
      <div class="mb-3"><label class="form-label small fw-semibold">Due Date *</label>
        <input type="date" name="due_date" class="form-control" required></div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg me-1"></i>Generate</button>
        <a href="/finance" class="btn btn-outline-secondary">Cancel</a>
      </div>
    </form>
  </div>
</div>
</div></div>
