<?php
/** @var array $exam    */
/** @var array $results */
/** @var array $students - students in this exam's class */
/** @var array $subjects */
$canGrade = \Core\Session::can('exams.grade');
$examID   = $exam['id'] ?? 0;

// Group existing results: [student_id][subject_id] = result
$existing = [];
foreach ($results as $r) {
    $existing[$r['student_id']][$r['subject_id']] = $r;
}

// Get unique students and subjects from results
$studentIndex = [];
$subjectIndex = [];
foreach ($results as $r) {
    $studentIndex[$r['student_id']] = ['id' => $r['student_id'], 'name' => $r['student_name'], 'admission_no' => $r['admission_no']];
    $subjectIndex[$r['subject_id']] = ['id' => $r['subject_id'], 'name' => $r['subject_name'], 'code' => $r['subject_code']];
}
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-0 small">
        <li class="breadcrumb-item"><a href="/exams">Exams</a></li>
        <li class="breadcrumb-item active"><?= htmlspecialchars($exam['name'] ?? '') ?></li>
      </ol>
    </nav>
    <h5 class="fw-bold mb-0 mt-1">
      <i class="bi bi-list-ol me-2 text-warning"></i><?= htmlspecialchars($exam['name'] ?? '') ?> — Results
    </h5>
  </div>
  <div class="d-flex gap-2">
    <?php if ($canGrade): ?>
      <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#enterResultsModal">
        <i class="bi bi-pencil-square me-1"></i>Enter Results
      </button>
    <?php endif; ?>
    <?php if (!empty($results)): ?>
      <a href="/reports/class-results?exam_id=<?= $examID ?>" class="btn btn-outline-info btn-sm">
        <i class="bi bi-bar-chart me-1"></i>Full Report
      </a>
    <?php endif; ?>
    <a href="/exams" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left me-1"></i>Back</a>
  </div>
</div>

<!-- Exam meta pills -->
<div class="d-flex gap-2 mb-3 flex-wrap">
  <span class="badge bg-warning-subtle text-warning border border-warning-subtle">
    <i class="bi bi-tag me-1"></i><?= ucfirst($exam['type'] ?? '') ?>
  </span>
  <span class="badge bg-secondary-subtle text-secondary border">
    <i class="bi bi-calendar me-1"></i><?= $exam['start_date'] ?? '' ?> → <?= $exam['end_date'] ?? '' ?>
  </span>
  <span class="badge bg-primary-subtle text-primary border">
    <i class="bi bi-people me-1"></i><?= count($studentIndex) ?> student<?= count($studentIndex) !== 1 ? 's' : '' ?>
  </span>
  <span class="badge bg-info-subtle text-info border">
    <i class="bi bi-book me-1"></i><?= count($subjectIndex) ?> subject<?= count($subjectIndex) !== 1 ? 's' : '' ?>
  </span>
</div>

<?php if (empty($results)): ?>
  <div class="card">
    <div class="card-body text-center py-5 text-muted">
      <i class="bi bi-clipboard-x fs-1 d-block mb-2 opacity-25"></i>
      No results submitted yet.
      <?php if ($canGrade): ?>
        <div class="mt-3">
          <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#enterResultsModal">
            <i class="bi bi-pencil-square me-1"></i>Enter Results Now
          </button>
        </div>
      <?php endif; ?>
    </div>
  </div>
<?php else: ?>
  <!-- Results grid: students as rows, subjects as columns -->
  <div class="card">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
      <span><i class="bi bi-table me-1"></i>Results Grid</span>
      <button class="btn btn-sm btn-outline-secondary" onclick="window.print()">
        <i class="bi bi-printer me-1"></i>Print
      </button>
    </div>
    <div class="card-body p-0" style="overflow-x:auto">
      <table class="table table-bordered table-hover table-sm mb-0" style="min-width:500px">
        <thead class="table-light">
          <tr>
            <th style="min-width:160px;position:sticky;left:0;background:#f9fafb">Student</th>
            <th style="min-width:60px;background:#f9fafb">Adm No</th>
            <?php foreach ($subjectIndex as $sub): ?>
              <th class="text-center" style="min-width:80px;font-size:.75rem">
                <span class="badge bg-primary-subtle text-primary"><?= htmlspecialchars($sub['code']) ?></span>
                <div style="font-size:.65rem;color:#6b7280;font-weight:400"><?= htmlspecialchars($sub['name']) ?></div>
              </th>
            <?php endforeach; ?>
            <th class="text-center" style="min-width:70px">Total</th>
            <th class="text-center" style="min-width:70px">Avg%</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($studentIndex as $st):
            $totalMarks = 0; $totalMax = 0;
            foreach ($subjectIndex as $sub) {
              $r = $existing[$st['id']][$sub['id']] ?? null;
              if ($r) { $totalMarks += $r['marks']; $totalMax += $r['max_marks']; }
            }
            $avg = $totalMax > 0 ? round($totalMarks / $totalMax * 100, 1) : null;
          ?>
          <tr>
            <td class="fw-semibold small" style="position:sticky;left:0;background:#fff">
              <?= htmlspecialchars($st['name']) ?>
            </td>
            <td class="small text-muted"><?= htmlspecialchars($st['admission_no']) ?></td>
            <?php foreach ($subjectIndex as $sub):
              $r = $existing[$st['id']][$sub['id']] ?? null;
            ?>
            <td class="text-center">
              <?php if ($r): ?>
                <span class="fw-bold"><?= $r['marks'] ?></span>
                <span class="text-muted small">/<?= $r['max_marks'] ?></span>
                <div>
                  <span class="badge <?= $r['marks']/$r['max_marks'] >= 0.5 ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger' ?>" style="font-size:.65rem">
                    <?= $r['grade'] ?>
                  </span>
                </div>
              <?php else: ?>
                <span class="text-muted">—</span>
              <?php endif; ?>
            </td>
            <?php endforeach; ?>
            <td class="text-center fw-bold small"><?= $totalMax > 0 ? "{$totalMarks}/{$totalMax}" : '—' ?></td>
            <td class="text-center">
              <?php if ($avg !== null): ?>
                <span class="badge <?= $avg >= 50 ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger' ?>">
                  <?= $avg ?>%
                </span>
              <?php else: ?>
                <span class="text-muted">—</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endif; ?>

<?php if ($canGrade): ?>
<!-- Enter Results Modal -->
<div class="modal fade" id="enterResultsModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Enter Results — <?= htmlspecialchars($exam['name'] ?? '') ?></h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form method="POST" action="/exams/results">
          <input type="hidden" name="exam_id" value="<?= $examID ?>">

          <div class="row g-3 mb-3">
            <div class="col-md-4">
              <label class="form-label small fw-semibold">Student *</label>
              <select name="student_id" class="form-select" required>
                <option value="">Select student...</option>
                <?php foreach ($students as $s):
                  $sName = trim(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? ''));
                ?>
                  <option value="<?= $s['id'] ?>"><?= htmlspecialchars($sName) ?> (<?= htmlspecialchars($s['admission_no'] ?? '') ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label small fw-semibold">Subject *</label>
              <select name="subject_id" class="form-select" required>
                <option value="">Select subject...</option>
                <?php foreach ($subjects as $sub): ?>
                  <option value="<?= $sub['id'] ?>"><?= htmlspecialchars($sub['name']) ?> (<?= htmlspecialchars($sub['code']) ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label small fw-semibold">Max Marks</label>
              <input type="number" name="max_marks" class="form-control" value="100" min="1" required>
            </div>
            <div class="col-md-4">
              <label class="form-label small fw-semibold">Marks Obtained *</label>
              <input type="number" name="marks" class="form-control" min="0" step="0.5" required>
            </div>
            <div class="col-md-8">
              <label class="form-label small fw-semibold">Remarks</label>
              <input type="text" name="remarks" class="form-control" placeholder="Optional teacher remarks">
            </div>
          </div>

          <div class="alert alert-info py-2 small">
            <i class="bi bi-info-circle me-1"></i>Grade is assigned automatically based on the school's grade scale.
            Submit one entry at a time; re-submitting the same student+subject updates the existing record.
          </div>

          <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-check-lg me-1"></i>Save Result
            </button>
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>
