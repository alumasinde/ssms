<?php
namespace Exams;
use Core\Controller;
use Core\Session;

class ExamsController extends Controller
{
    public function index(array $params = []): void
    {
        $this->requirePermission('exams.view');
        $res = $this->api->get('/exams');
        $this->view('exams/index', [
            'title' => 'Exams',
            'exams' => $res['data'] ?? [],
        ]);
    }

    public function create(array $params = []): void
    {
        $this->requirePermission('exams.create');
        // Load current academic year's terms for the dropdown
        $termsRes = $this->api->get('/academic-years/current');
        $yearID   = $termsRes['data']['id'] ?? 0;
        $terms    = [];
        if ($yearID) {
            // Terms are fetched via the school route
            $schoolID = \Core\Session::get('school_id', 0);
            $tRes     = $this->api->get("/schools/{$schoolID}/terms");
            $terms    = $tRes['data'] ?? [];
        }
        $this->view('exams/create', [
            'title' => 'Create Exam',
            'terms' => $terms,
        ]);
    }

    public function store(array $params = []): void
    {
        $this->requirePermission('exams.create');
        $res = $this->api->post('/exams', [
            'name'       => trim($_POST['name'] ?? ''),
            'type'       => $_POST['type'] ?? 'endterm',
            'term_id'    => (int)($_POST['term_id'] ?? 0),
            'start_date' => $_POST['start_date'] ?? '',
            'end_date'   => $_POST['end_date'] ?? '',
        ]);
        if ($res['success'] ?? false) {
            $this->redirect('/exams', 'Exam created.');
        }
        Session::flash('error', $res['error'] ?? 'Failed to create exam.');
        $this->redirect('/exams/create');
    }

    public function show(array $params): void
    {
        $this->requirePermission('exams.view');
        $id   = (int)$params['id'];
        $res  = $this->api->get("/exams/{$id}");
        if (!($res['success'] ?? false)) {
            $this->redirect('/exams', 'Exam not found.', 'error');
        }
        $this->view('exams/show', [
            'title' => $res['data']['name'] ?? 'Exam',
            'exam'  => $res['data'] ?? [],
        ]);
    }

    public function results(array $params): void
    {
        $this->requirePermission('exams.view');
        $examID   = (int)$params['id'];
        $res      = $this->api->get("/exams/{$examID}/results");
        $exam     = $this->api->get("/exams/{$examID}");
        $students = $this->api->get('/students');
        $subjects = $this->api->get('/subjects');
        $this->view('exams/results', [
            'title'    => 'Results — ' . ($exam['data']['name'] ?? ''),
            'results'  => $res['data'] ?? [],
            'exam'     => $exam['data'] ?? [],
            'students' => $students['data'] ?? [],
            'subjects' => $subjects['data'] ?? [],
        ]);
    }

    public function submitResults(array $params = []): void
    {
        $this->requirePermission('exams.grade');
        $res = $this->api->post('/exams/results', [
            'exam_id'    => (int)($_POST['exam_id'] ?? 0),
            'student_id' => (int)($_POST['student_id'] ?? 0),
            'subject_id' => (int)($_POST['subject_id'] ?? 0),
            'marks'      => (float)($_POST['marks'] ?? 0),
            'max_marks'  => (float)($_POST['max_marks'] ?? 100),
            'remarks'    => trim($_POST['remarks'] ?? ''),
        ]);
        $examID = $_POST['exam_id'] ?? '';
        if ($res['success'] ?? false) {
            $this->redirect("/exams/{$examID}/results", 'Result submitted.');
        }
        Session::flash('error', $res['error'] ?? 'Failed.');
        $this->redirect("/exams/{$examID}/results");
    }
}
