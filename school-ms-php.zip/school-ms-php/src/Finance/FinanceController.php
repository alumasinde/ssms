<?php
namespace Finance;
use Core\Controller;
use Core\Session;

class FinanceController extends Controller
{
    public function index(array $params = []): void
    {
        $this->requirePermission('finance.view');
        $feeTypes = $this->api->get('/finance/fee-types');
        $this->view('finance/index', [
            'title'    => 'Finance',
            'feeTypes' => $feeTypes['data'] ?? [],
        ]);
    }

    public function createFeeType(array $params = []): void
    {
        $this->requirePermission('finance.create');
        $this->view('finance/create_fee_type', ['title' => 'Add Fee Type']);
    }

    public function storeFeeType(array $params = []): void
    {
        $this->requirePermission('finance.create');
        $res = $this->api->post('/finance/fee-types', [
            'name'         => trim($_POST['name'] ?? ''),
            'amount'       => (float)($_POST['amount'] ?? 0),
            'frequency'    => $_POST['frequency'] ?? 'termly',
            'is_mandatory' => isset($_POST['is_mandatory']) ? 1 : 0,
        ]);
        if ($res['success'] ?? false) {
            $this->redirect('/finance', 'Fee type created.');
        }
        Session::flash('error', $res['error'] ?? 'Failed to create fee type.');
        $this->redirect('/finance/fee-types/create');
    }

    public function statement(array $params): void
    {
        $this->requirePermission('finance.view');
        $studentID = (int)$params['studentId'];
        $student   = $this->api->get("/students/{$studentID}");
        $stmt      = $this->api->get("/finance/statement/student/{$studentID}");
        $this->view('finance/statement', [
            'title'     => 'Fee Statement',
            'student'   => $student['data'] ?? [],
            'statement' => $stmt['data'] ?? [],
        ]);
    }

    public function recordPayment(array $params = []): void
    {
        $this->requirePermission('finance.create');
        $studentID = (int)($_POST['student_id'] ?? 0);
        $res = $this->api->post('/finance/payments', [
            'invoice_id'  => (int)($_POST['invoice_id'] ?? 0),
            'amount_paid' => (float)($_POST['amount_paid'] ?? 0),
            'method'      => $_POST['method'] ?? 'cash',
            'ref_no'      => trim($_POST['ref_no'] ?? ''),
            'mpesa_code'  => trim($_POST['mpesa_code'] ?? ''),
            'notes'       => trim($_POST['notes'] ?? ''),
        ]);
        if ($res['success'] ?? false) {
            $this->redirect("/finance/statement/{$studentID}", 'Payment recorded successfully.');
        }
        Session::flash('error', $res['error'] ?? 'Failed to record payment.');
        $this->redirect("/finance/statement/{$studentID}");
    }

    public function generateInvoices(array $params = []): void
    {
        $this->requirePermission('finance.create');
        $this->view('finance/generate_invoices', ['title' => 'Generate Invoices']);
    }

    public function storeInvoices(array $params = []): void
    {
        $this->requirePermission('finance.create');
        $res = $this->api->post('/finance/invoices/generate', [
            'term_id'     => (int)($_POST['term_id'] ?? 0),
            'fee_type_id' => (int)($_POST['fee_type_id'] ?? 0),
            'class_id'    => (int)($_POST['class_id'] ?? 0) ?: null,
            'due_date'    => $_POST['due_date'] ?? '',
        ]);
        if ($res['success'] ?? false) {
            $this->redirect('/finance', 'Invoices generated successfully.');
        }
        Session::flash('error', $res['error'] ?? 'Failed to generate invoices.');
        $this->redirect('/finance/invoices/generate');
    }
}
