<?php
namespace Dashboard;
use Core\Controller;
use Core\Session;

class DashboardController extends Controller
{
    public function index(array $params = []): void
    {
        $this->requireAuth();

        $totalStudents = 0;
        $totalTeachers = 0;
        $totalParents  = 0;
        $recentNotices = [];

        // Only fetch what the role can see
        if ($this->can('students.view')) {
            $students      = $this->api->get('/students', ['per_page' => 1]);
            $totalStudents = $students['meta']['total'] ?? 0;
        }
        if ($this->can('teachers.view')) {
            $teachers      = $this->api->get('/teachers');
            $totalTeachers = count($teachers['data'] ?? []);
        }
        if ($this->can('parents.view')) {
            $parents      = $this->api->get('/parents');
            $totalParents = count($parents['data'] ?? []);
        }
        if ($this->can('notices.view')) {
            $notices       = $this->api->get('/notices');
            $recentNotices = array_slice($notices['data'] ?? [], 0, 5);
        }

        $this->view('dashboard/index', [
            'title'          => 'Dashboard',
            'totalStudents'  => $totalStudents,
            'totalTeachers'  => $totalTeachers,
            'totalParents'   => $totalParents,
            'recentNotices'  => $recentNotices,
        ]);
    }
}
