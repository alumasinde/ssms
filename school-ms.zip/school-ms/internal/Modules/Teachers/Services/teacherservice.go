package services

import (
	dtos   "school-ms/internal/Modules/Teachers/DTOs"
	models "school-ms/internal/Modules/Teachers/Models"
	repos  "school-ms/internal/Modules/Teachers/Repositories"
)

type TeacherService struct{ repo *repos.TeacherRepository }

func NewTeacherService(repo *repos.TeacherRepository) *TeacherService {
	return &TeacherService{repo: repo}
}

func (s *TeacherService) Create(dto dtos.CreateTeacherDTO) (*models.Teacher, error) {
	t := &models.Teacher{
		UserID: dto.UserID, SchoolID: dto.SchoolID, EmployeeNo: dto.EmployeeNo,
		Phone: dto.Phone, Gender: dto.Gender, DOB: dto.DOB, TSCNo: dto.TSCNo, HireDate: dto.HireDate,
		Qualification: dto.Qualification, PhotoURL: dto.PhotoURL,
	}
	return t, s.repo.Create(t)
}

func (s *TeacherService) GetByID(id int64) (*models.TeacherDetail, error) { return s.repo.FindByID(id) }

func (s *TeacherService) List(schoolID int64) ([]models.TeacherDetail, error) {
	return s.repo.ListBySchool(schoolID)
}

//Update Teacher details except for UserID, SchoolID and EmployeeNo which are immutable after creation. Use DTO UpdateTeacher
func (s *TeacherService) Update(t dtos.UpdateTeacherDTO) (*models.TeacherDetail, error) {
	teacher, err := s.repo.FindByID(t.ID)
	if err != nil {
		return nil, err
	}
	teacher.Phone = t.Phone
	teacher.Gender = t.Gender
	teacher.DOB = t.DOB
	teacher.TSCNo = t.TSCNo
	teacher.HireDate = t.HireDate
	teacher.Qualification = t.Qualification
	teacher.PhotoURL = t.PhotoURL

	if err := s.repo.Update(&models.Teacher{
		ID: teacher.ID, Phone: teacher.Phone, Gender: teacher.Gender, DOB: teacher.DOB, TSCNo: teacher.TSCNo, HireDate: teacher.HireDate,
		Qualification: teacher.Qualification, PhotoURL: teacher.PhotoURL,
	}); err != nil {
		return nil, err
	}
	return teacher, nil
}


func (s *TeacherService) AssignSubject(dto dtos.AssignSubjectDTO) error {
	return s.repo.AssignSubject(&models.TeacherSubject{
		TeacherID: dto.TeacherID, SubjectID: dto.SubjectID, ClassID: dto.ClassID,
	})
}

func (s *TeacherService) GetSubjects(teacherID int64) ([]models.TeacherSubjectDetail, error) {
	return s.repo.GetSubjectsByTeacher(teacherID)
}

func (s *TeacherService) RemoveSubject(teacherID, subjectID, classID int64) error {
	return s.repo.RemoveSubject(teacherID, subjectID, classID)
}
