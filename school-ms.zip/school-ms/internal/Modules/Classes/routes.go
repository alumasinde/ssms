package classes

import (
	handlers "school-ms/internal/Modules/Classes/Handlers"
	repos "school-ms/internal/Modules/Classes/Repositories"
	services "school-ms/internal/Modules/Classes/Services"
	"school-ms/internal/middleware"

	"github.com/go-chi/chi/v5"
	"github.com/jmoiron/sqlx"
)

func RegisterRoutes(r chi.Router, db *sqlx.DB) {
	repo := repos.NewClassRepository(db)
	svc := services.NewClassService(repo)
	h := handlers.NewClassHandler(svc)

	r.Route("/classes", func(r chi.Router) {
		r.Use(middleware.Authenticate)

		r.With(middleware.RequirePermission(db, "classes.view")).Get("/", h.List)
		r.With(middleware.RequirePermission(db, "classes.create")).Post("/", h.Create)
		r.With(middleware.RequirePermission(db, "classes.view")).Get("/{id}", h.Get)
		r.With(middleware.RequirePermission(db, "classes.edit")).Put("/{id}", h.Update)
		r.With(middleware.RequirePermission(db, "classes.delete")).Delete("/{id}", h.Delete)
	})
}
